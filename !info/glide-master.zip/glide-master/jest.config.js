export default {
  testEnvironment: 'jsdom'
}
